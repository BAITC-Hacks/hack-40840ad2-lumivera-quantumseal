@echo off
chcp 65001 >nul
title LQ Experiment 01 v0.1
where py >nul 2>nul
if %errorlevel%==0 (
  py -3 run_experiment.py
) else (
  python run_experiment.py
)
echo.
echo Нажмите любую клавишу, чтобы закрыть окно.
pause >nul

