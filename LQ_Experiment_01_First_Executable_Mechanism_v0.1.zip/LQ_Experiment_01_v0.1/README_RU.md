# LQ Experiment 01 — первый исполняемый механизм v0.1

Автор/архитектор: Татьяна Геннадьевна Дидух  
Проект: LUMIVERA QuantumSeal  
Статус: внутренний исследовательский прототип, только синтетические данные.

## Что проверяет пакет

Один синтетический документ проходит локальный маршрут:

`Intake → Validator → Local Index → Evidence Builder → LQ Bus Adapter → Human Decision → T1`

Пакет не содержит реальных персональных, медицинских, клиентских или коммерческих данных. Он не раскрывает закрытые алгоритмы LQ Core, веса VEXEL L100, правила оркестрации или коммерческие механики.

## Требования

- Windows 11 или Linux/macOS;
- Python 3.10 или новее;
- интернет не нужен;
- сторонние библиотеки не нужны.

## Запуск на Windows 11

1. Распакуйте ZIP в отдельную папку.
2. Дважды нажмите `RUN_EXPERIMENT_01.bat`.
3. После завершения откройте папку `output`.

Альтернативно в PowerShell:

```powershell
py -3 run_experiment.py
```

## Ожидаемый результат

- `output/EXPERIMENT_REPORT.txt` — итог PASS/FAIL и измерения;
- `output/local_index.jsonl` — локальный индекс;
- `output/evidence/*.json` — Evidence-записи;
- `output/bus/*.json` — события LQ Bus;
- `output/audit_log.jsonl` — журнал стадий;
- `output/t1_state.json` — T1 и решение STOP / ITERATE / SCALE.

Успех v0.1: валидный синтетический документ проходит полный маршрут, дубликат обнаруживается, запрещённый удалённый маршрут блокируется, неполный документ переводится в manual review, а Evidence и Bus cross-links проходят проверку.

