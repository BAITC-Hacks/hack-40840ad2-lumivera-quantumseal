from __future__ import annotations

import csv
import hashlib
import json
import shutil
import sys
import time
from datetime import datetime, timezone
from pathlib import Path

ROOT = Path(__file__).resolve().parent
INPUT = ROOT / "synthetic_data"
OUTPUT = ROOT / "output"
VERSION = "0.1.0"
COMPUTE_REF = "NODE-LOCAL-SYNTH-01"
POLICY_REF = "POLICY-LQ06-SYNTH-01"


def now() -> str:
    return datetime.now(timezone.utc).isoformat().replace("+00:00", "Z")


def canonical_bytes(value) -> bytes:
    if isinstance(value, (dict, list)):
        return json.dumps(value, ensure_ascii=False, sort_keys=True, separators=(",", ":")).encode("utf-8")
    return str(value).encode("utf-8")


def digest(value) -> str:
    return "sha256:" + hashlib.sha256(canonical_bytes(value)).hexdigest()


def write_json(path: Path, value) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(value, ensure_ascii=False, indent=2), encoding="utf-8")


def append_jsonl(path: Path, value) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("a", encoding="utf-8") as f:
        f.write(json.dumps(value, ensure_ascii=False, sort_keys=True) + "\n")


def audit(stage: str, status: str, correlation_id: str, detail: str) -> None:
    append_jsonl(OUTPUT / "audit_log.jsonl", {
        "timestamp": now(), "stage": stage, "status": status,
        "correlation_id": correlation_id, "detail": detail,
    })


def validate_contract(obj: dict, required: list[str], allowed: set[str], name: str) -> None:
    missing = [key for key in required if key not in obj]
    extra = sorted(set(obj) - allowed)
    if missing or extra:
        raise ValueError(f"{name}: missing={missing}; extra={extra}")


def validate_passport(passport: dict) -> None:
    required = ["schema_version", "module_id", "module_version", "class", "business_capabilities", "runtime", "data", "ai", "security", "evidence", "interfaces", "degraded_mode"]
    validate_contract(passport, required, set(required), "LQ-PASSPORT")
    if passport["schema_version"] != "0.1" or passport["module_id"] != "LQ-06":
        raise ValueError("LQ-PASSPORT: incompatible identity/version")
    if passport["runtime"].get("min_ram_mb", 0) < 512:
        raise ValueError("LQ-PASSPORT: invalid min_ram_mb")


BUS_FIELDS = {"schema_version", "event_id", "event_type", "source_lq", "destination", "timestamp", "correlation_id", "data_class", "permission_level", "operation", "payload_ref", "model_ref", "compute_ref", "result_status", "confidence", "evidence_id", "integrity_hash", "human_review_status"}
BUS_REQUIRED = ["schema_version", "event_id", "event_type", "source_lq", "destination", "timestamp", "correlation_id", "data_class", "permission_level", "operation", "result_status", "human_review_status"]
EVIDENCE_FIELDS = {"schema_version", "evidence_id", "correlation_id", "source_ref", "source_hash", "input_snapshot_ref", "transform_ref", "model_ref", "compute_ref", "policy_ref", "output_ref", "output_hash", "timestamp", "human_decision_ref", "parent_evidence_id", "integrity_signature"}
EVIDENCE_REQUIRED = ["schema_version", "evidence_id", "correlation_id", "source_ref", "source_hash", "input_snapshot_ref", "transform_ref", "compute_ref", "policy_ref", "output_ref", "output_hash", "timestamp"]


def validate_bus(bus: dict) -> None:
    validate_contract(bus, BUS_REQUIRED, BUS_FIELDS, "LQBUS")
    if bus["schema_version"] != "0.1":
        raise ValueError("LQBUS: incompatible schema_version")


def validate_evidence(evidence: dict) -> None:
    validate_contract(evidence, EVIDENCE_REQUIRED, EVIDENCE_FIELDS, "LQ-EVIDENCE")
    if evidence["schema_version"] != "0.1":
        raise ValueError("LQ-EVIDENCE: incompatible schema_version")


def cross_validate(bus: dict, evidence: dict, passport: dict) -> None:
    checks = {
        "X-01": bus.get("evidence_id") == evidence.get("evidence_id"),
        "X-02": bus.get("source_lq") == passport.get("module_id"),
        "X-03": bus.get("model_ref") == evidence.get("model_ref"),
        "X-04": bus.get("compute_ref") == evidence.get("compute_ref"),
        "X-05": bus.get("correlation_id") == evidence.get("correlation_id"),
        "X-06": bus.get("human_review_status") not in {"APPROVED", "REJECTED"} or bool(evidence.get("human_decision_ref")),
    }
    failed = [key for key, passed in checks.items() if not passed]
    if failed:
        raise ValueError("cross-schema failed: " + ", ".join(failed))


def route_allowed(row: dict) -> tuple[bool, str]:
    if row["data_class"] == "RESTRICTED" and row["requested_route"] != "local":
        return False, "RESTRICTED data cannot use remote route"
    return True, "local route allowed"


def load_rows() -> list[dict]:
    with (INPUT / "synthetic_documents.csv").open(encoding="utf-8-sig", newline="") as f:
        return list(csv.DictReader(f))


def run() -> int:
    started = time.perf_counter()
    if OUTPUT.exists():
        shutil.rmtree(OUTPUT)
    OUTPUT.mkdir(parents=True)
    passport = json.loads((ROOT / "contracts" / "LQ06-passport-example.json").read_text(encoding="utf-8"))
    validate_passport(passport)
    rows = load_rows()
    seen_hashes: set[str] = set()
    counts = {"total": len(rows), "completed": 0, "duplicates": 0, "denied": 0, "manual_review": 0, "evidence_valid": 0}

    for number, row in enumerate(rows, 1):
        cid = row["correlation_id"]
        audit("INTAKE", "RECEIVED", cid, "synthetic row accepted")
        source_hash = digest(row)
        if source_hash in seen_hashes or row.get("duplicate_of"):
            counts["duplicates"] += 1
            audit("VALIDATOR", "DUPLICATE", cid, row.get("duplicate_of") or "hash match")
            continue
        seen_hashes.add(source_hash)

        allowed, reason = route_allowed(row)
        if not allowed:
            counts["denied"] += 1
            audit("ROUTER", "DENY", cid, reason)
            continue

        missing = [field for field in ("document_id", "amount", "currency", "document_date") if not row.get(field)]
        review = bool(missing) or row.get("ai_available", "true").lower() != "true"
        decision_ref = f"DEC-SYNTH-{number:03d}" if review else None
        if review:
            counts["manual_review"] += 1
            audit("HUMAN_DECISION", "PENDING", cid, "missing=" + ",".join(missing) if missing else "AI disabled")

        result = {
            "document_id": row.get("document_id"), "validation": "NEEDS_REVIEW" if review else "VALID",
            "missing_fields": missing, "route": "local", "synthetic": True,
        }
        evidence_id = f"EVD-SYNTH-{number:03d}"
        evidence = {
            "schema_version": "0.1", "evidence_id": evidence_id, "correlation_id": cid,
            "source_ref": f"synthetic://input/{row.get('document_id') or number}", "source_hash": source_hash,
            "input_snapshot_ref": f"SNAP-SYNTH-{number:03d}", "transform_ref": f"LQ06-executable:{VERSION}",
            "model_ref": None, "compute_ref": COMPUTE_REF, "policy_ref": POLICY_REF,
            "output_ref": f"local://output/result/{number:03d}", "output_hash": digest(result),
            "timestamp": now(), "human_decision_ref": decision_ref, "parent_evidence_id": None,
            "integrity_signature": None,
        }
        bus = {
            "schema_version": "0.1", "event_id": f"EVT-SYNTH-{number:03d}", "event_type": "REVIEW" if review else "RESULT",
            "source_lq": "LQ-06", "destination": "HUMAN-REVIEW" if review else "LUMIVERA-CORE",
            "timestamp": now(), "correlation_id": cid, "data_class": row["data_class"],
            "permission_level": "LQ06_SYNTH_RESULT", "operation": "synthetic_document_validation",
            "payload_ref": evidence["output_ref"], "model_ref": None, "compute_ref": COMPUTE_REF,
            "result_status": "NEEDS_REVIEW" if review else "SUCCESS", "confidence": None,
            "evidence_id": evidence_id, "integrity_hash": digest(evidence),
            "human_review_status": "PENDING" if review else "NOT_REQUIRED",
        }
        validate_evidence(evidence)
        validate_bus(bus)
        cross_validate(bus, evidence, passport)
        write_json(OUTPUT / "evidence" / f"{evidence_id}.json", evidence)
        write_json(OUTPUT / "bus" / f"{bus['event_id']}.json", bus)
        append_jsonl(OUTPUT / "local_index.jsonl", {"correlation_id": cid, "source_hash": source_hash, "evidence_id": evidence_id, "status": result["validation"]})
        audit("EVIDENCE", "PASS", cid, "X-01..X-06 passed")
        counts["evidence_valid"] += 1
        counts["completed"] += 1

    elapsed_ms = round((time.perf_counter() - started) * 1000, 3)
    expected = {"total": 4, "completed": 2, "duplicates": 1, "denied": 1, "manual_review": 1, "evidence_valid": 2}
    passed = all(counts[key] == value for key, value in expected.items())
    t1 = {
        "experiment": "LQ Experiment 01", "version": VERSION, "synthetic_data_only": True,
        "T0": {"executable_routes": 0, "validated_evidence_records": 0},
        "T1": {"executable_routes": counts["completed"], "validated_evidence_records": counts["evidence_valid"]},
        "measurements": {**counts, "latency_ms_total": elapsed_ms, "external_data_transfer_bytes": 0},
        "decision": "ITERATE" if passed else "STOP",
        "criterion": "PASS" if passed else "FAIL",
    }
    write_json(OUTPUT / "t1_state.json", t1)
    report = [
        "LQ EXPERIMENT 01 — EXECUTION REPORT v0.1", "=" * 46,
        "DATA: SYNTHETIC ONLY", f"RESULT: {'PASS' if passed else 'FAIL'}",
        f"DECISION: {t1['decision']}", "",
        *[f"{key}: {value}" for key, value in counts.items()],
        f"latency_ms_total: {elapsed_ms}", "external_data_transfer_bytes: 0", "",
        "Interpretation: the minimal local mechanism executed and produced traceable artifacts." if passed else "Interpretation: expected controls did not all pass; execution must stop.",
        "This result does not prove industrial readiness, patentability, scientific novelty, or superiority.",
    ]
    (OUTPUT / "EXPERIMENT_REPORT.txt").write_text("\n".join(report), encoding="utf-8")
    print("\n".join(report))
    print(f"\nАртефакты: {OUTPUT}")
    return 0 if passed else 1


if __name__ == "__main__":
    try:
        sys.exit(run())
    except Exception as exc:
        OUTPUT.mkdir(parents=True, exist_ok=True)
        (OUTPUT / "FATAL_ERROR.txt").write_text(str(exc), encoding="utf-8")
        print("STOP:", exc)
        sys.exit(2)

